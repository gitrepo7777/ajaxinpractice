package org.bibeault.aip.search;

public interface WebSearchResult {
    public String getTitle();
    public String getSummary();
    public String getUrl();
}
