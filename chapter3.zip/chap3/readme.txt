This folder contains the example code for Chapter 3.

The files and sub-folders within this folder consist of:

  Button.js           Implementation of the Button class
  ButtonP.js          Implemantation of the Button class using Prototype
  CD.js               Implementation of the CD class
  DVD.js              Implementation of the DVD class
  Disc.js             Implementation of the Disc class
  button-test.html    Test page for the Button classes
  button-test-p.html  Test page for the ButtonP classes
  disc-test.html      Test page for the Disc and related classes

The HTML files do not rely upon any server-side resources, so you can either
serve them via a web server or simply open them in your browser.

These pages and classes have been tested in Safari 2.0, Firefox 1.5 and
Internet Explorer 6.
